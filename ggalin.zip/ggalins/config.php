<?php

return [
    'db_name' => 'ggalin',
    'db_host' => 'localhost',
    'db_user' => 'root',
    'db_pass' => '',
];
?>